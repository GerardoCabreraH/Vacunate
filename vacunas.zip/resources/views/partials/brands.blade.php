<section class="background-dark">
    <div class="container">
        <div class="row">
            <div class="col-12 col-sm-3 mt-5">
                <img src="{{asset('assets/img/astrazeneca.png')}}" alt="astrazeneca" class="img-fluid img-logos">
            </div>
            <div class="col-12 col-sm-3 mt-5">
                <img src="{{asset('assets/img/sinovac.png')}}" alt="sinovac" class="img-fluid img-logos">
            </div>
            <div class="col-12 col-sm-3 mt-5">
                <img src="{{asset('assets/img/pfizer.png')}}" alt="pfizer" class="img-fluid img-logos">
            </div>
            <div class="col-12 col-sm-3 mt-5">
                <img src="{{asset('assets/img/moderna.png')}}" alt="moderna" class="img-fluid img-logos">
            </div>
        </div>
    </div>
</section>
