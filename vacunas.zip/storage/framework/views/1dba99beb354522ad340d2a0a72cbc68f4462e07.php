<?php if(session('status')): ?>
<div class="alert alert-success" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
    <?php echo e(session('status')); ?>

</div>
<?php endif; ?>
<?php /**PATH C:\laragon\www\vacunas\resources\views/partials/status-admin.blade.php ENDPATH**/ ?>