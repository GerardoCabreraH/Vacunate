<?php $__env->startSection('title', 'Vacunate | Gestión de citas'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.header-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main id="dashboard" class="content">
    <section id="count" class="section-light">
        <div class="container">
            <div class="row">
                <div class="col-12 col-sm-12">
                    <?php echo $__env->make('partials.status-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <h1 class="text-center">Gestión de citas</h1>
                </div>
                <div class="col-12 col-sm-12">
                    <div class="row">
                        <div class="col-12 col-sm-12">
                            <div class="card text-white bg-success mb-3">
                                <div class="card-body text-center">
                                    <p><span class="icon-dashboard"><i class="fas fa-list"></i></span></p>
                                    <?php if($citas->count() == 1): ?>
                                        <p><?php echo e($citas->count()); ?> Cita</p>
                                    <?php else: ?>
                                        <p><?php echo e($citas->count()); ?> Citas</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id="citas" class="section-light">
        <div class="container">
            <div class="card shadow">
                <div class="card-body">
                    <div class="row">
                        <div class="col-12 col-sm-12">
                            <h2 class="text-center">Tabla de citas</h2>
                        </div>
                        <div class="col-12 col-sm-12 mt-5">
                            <table id="tablaDashboard" class="table table-hover text-nowrap table-bordered">
                                <thead>
                                    <tr>
                                        <th>Codigo de la cita</th>
                                        <th>Nombre del paciente</th>
                                        <th>Folio MiVacuna</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $citas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td data-label="Código de la cita">
                                                <p class="mt-2"><?php echo e($cita->code); ?></p>
                                            </td>
                                            <td data-label="Nombre del paciente">
                                                <p class="mt-2"><?php echo e($cita->name); ?></p>
                                            </td>
                                            <td data-label="Folio MiVacuna">
                                                <p class="mt-2"><?php echo e($cita->folio); ?></p>
                                            </td>
                                            <td data-label="Acciones">
                                                <div class="form-group d-flex align-items-sm-center flex-sm-row flex-column mt-2">
                                                    <div class="p-1">
                                                        <a class="btn btn-primary" href="<?php echo e(route('appointments.show', $cita)); ?>">Ver</a>
                                                    </div>
                                                    <div class="p-1">
                                                        <a class="btn btn-warning" href="<?php echo e(route('appointments.edit', $cita)); ?>">Editar</a>
                                                    </div>
                                                    <div class="p-1">
                                                        <a class="btn btn-danger" href="<?php echo e(route('appointments.destroy', $cita)); ?>" onclick="event.preventDefault(); document.getElementById('delete-data').submit();">
                                                            Eliminar
                                                        </a>
                                                        <form id="delete-data" action="<?php echo e(route('appointments.destroy', $cita)); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                        </form>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="4" data-label="Codigo" class="text-center">
                                                Sin resultados
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                            <?php echo $citas->links(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vacunas\resources\views/admin/appointments/index.blade.php ENDPATH**/ ?>