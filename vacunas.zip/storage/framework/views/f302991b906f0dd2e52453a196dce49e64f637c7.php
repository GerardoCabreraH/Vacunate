<?php $__env->startSection('title', 'Vacunate | Reserva tu lugar para vacunarte'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.header-guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--Contenido de la pagina-->
<main>
    <?php echo $__env->make('partials.brands', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section id="formulario" class="background">
        <div class="container">
            <div class="row">
                <div class="col-12 col-sm-12">
                    <h2 class="titlePrimary">Reserva tu lugar para vacunarte</h2>
                    <p>En este formulario ahora puedes reservar tu lugar para que seas vacunado, la ubicación debe de ser
                        igual a la de tu credencial de elector.</p>
                    <div class="form-group">
                        <p><strong>Ubicación del modulo:</strong> <?php echo e($modulo->city); ?>, <?php echo e($modulo->state); ?></p>
                    </div>
                    <div class="form-group">
                        <p><strong>Marca de la vacuna:</strong> <?php echo e($modulo->brand); ?></p>
                    </div>
                    <div class="form-group">
                        <p><strong>Fecha de vacunación:</strong> <?php echo e($diassemana[date('w', strtotime($modulo->date_module))]." ".date('d', strtotime($modulo->date_module))." de
                        ".$meses[date('n', strtotime($modulo->date_module))-1]. " del ".date('Y', strtotime($modulo->date_module))); ?></p>
                    </div>
                </div>
                <div class="col-12 col-sm-12 mt-4">
                    <form role="form" action="<?php echo e(route('appointments.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo $__env->make('admin.appointments.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="form-group">
                            <button type="submit" class="btn btn-vaccination-2 btn-block">Enviar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
</main>
<?php echo $__env->make('partials.footer-guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vacunas\resources\views/webpage/booking-vaccine.blade.php ENDPATH**/ ?>