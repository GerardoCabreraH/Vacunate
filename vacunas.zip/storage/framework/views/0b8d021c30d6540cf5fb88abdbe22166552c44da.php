<?php $__env->startSection('title', 'Vacunate | Gestión de usuarios'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.header-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main id="dashboard" class="content">
    <section id="count" class="section-light">
        <div class="container">
            <div class="row">
                <div class="col-12 col-sm-12">
                    <?php echo $__env->make('partials.status-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <h1 class="text-center">Gestión de usuarios</h1>
                </div>
                <div class="col-12 col-sm-12">
                    <div class="row">
                        <div class="col-12 col-sm-12">
                            <div class="card text-white bg-success mb-3">
                                <div class="card-body text-center">
                                    <p><span class="icon-dashboard"><i class="fas fa-user"></i></span></p>
                                    <?php if($usuarios->count() == 1): ?>
                                        <p><?php echo e($usuarios->count()); ?> Usuario</p>
                                    <?php else: ?>
                                        <p><?php echo e($usuarios->count()); ?> Usuarios</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id="usuarios" class="section-light">
        <div class="container">
            <div class="card shadow">
                <div class="card-body">
                    <div class="row">
                        <div class="col-12 col-sm-12">
                            <h2 class="text-center">Tabla de usuarios</h2>
                            <a href="<?php echo e(route('users.create')); ?>" class="btn btn-success btn-block">Crear</a>
                        </div>
                        <div class="col-12 col-sm-12 mt-5">
                            <table id="tablaDashboard" class="table table-hover text-nowrap table-bordered">
                                <thead>
                                    <tr>
                                        <th>Codigo del usuario</th>
                                        <th>Nombre del usuario</th>
                                        <th>Rol del usuario</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td data-label="Código del usuario">
                                                <p class="mt-2"><?php echo e($usuario->code); ?></p>
                                            </td>
                                            <td data-label="Nombre del usuario">
                                                <p class="mt-2"><?php echo e($usuario->name); ?></p>
                                            </td>
                                            <td data-label="Rol del usuario">
                                                <p class="mt-2"><?php echo e($usuario->role); ?></p>
                                            </td>
                                            <td data-label="Acciones">
                                                <div class="form-group d-flex align-items-sm-center flex-sm-row flex-column mt-2">
                                                    <div class="p-1">
                                                        <a class="btn btn-primary" href="<?php echo e(route('users.show', $usuario)); ?>">Ver</a>
                                                    </div>
                                                    <div class="p-1">
                                                        <a class="btn btn-warning" href="<?php echo e(route('users.edit', $usuario)); ?>">Editar</a>
                                                    </div>
                                                    <div class="p-1">
                                                        <a class="btn btn-danger" href="<?php echo e(route('users.destroy', $usuario)); ?>" onclick="event.preventDefault(); document.getElementById('delete-data').submit();">
                                                            Eliminar
                                                        </a>
                                                        <form id="delete-data" action="<?php echo e(route('users.destroy', $usuario)); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                        </form>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="4" data-label="Codigo" class="text-center">
                                                Sin resultados
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                            <?php echo $usuarios->links(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vacunas\resources\views/admin/users/index.blade.php ENDPATH**/ ?>