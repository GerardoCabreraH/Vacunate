<?php $__env->startSection('title', 'Vacunate | Gestión de modulos'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.header-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main id="dashboard" class="content">
    <section id="count" class="section-light">
        <div class="container">
            <div class="row">
                <div class="col-12 col-sm-12">
                    <?php echo $__env->make('partials.status-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <h1 class="text-center">Gestión de modulos</h1>
                </div>
                <div class="col-12 col-sm-12">
                    <div class="row">
                        <div class="col-12 col-sm-12">
                            <div class="card text-white bg-success mb-3">
                                <div class="card-body text-center">
                                    <p><span class="icon-dashboard"><i class="fas fa-syringe"></i></span></p>
                                    <?php if($modulos->count() == 1): ?>
                                        <p><?php echo e($modulos->count()); ?> Modulo</p>
                                    <?php else: ?>
                                        <p><?php echo e($modulos->count()); ?> Modulos</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id="modulos" class="section-light">
        <div class="container">
            <div class="card shadow">
                <div class="card-body">
                    <div class="row">
                        <div class="col-12 col-sm-12">
                            <h2 class="text-center">Tabla de modulos</h2>
                            <a href="<?php echo e(route('modules.create')); ?>" class="btn btn-success btn-block">Crear</a>
                        </div>
                        <div class="col-12 col-sm-12 mt-5">
                            <ul class="list-group">
                                <?php $__empty_1 = true; $__currentLoopData = $modulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <li class="list-group-item"><a href="<?php echo e(route('modules.show', $modulo)); ?>">Ciudad: <?php echo e($modulo->city); ?> Estado: <?php echo e($modulo->state); ?> Vacuna: <?php echo e($modulo->brand); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <li class="list-group-item">Sin resultados</li>
                                <?php endif; ?>
                            </ul>
                            <?php echo $modulos->links(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vacunas\resources\views/admin/modules/index.blade.php ENDPATH**/ ?>