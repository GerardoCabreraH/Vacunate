<div class="form-group">
    <label for="city">Ciudad del modulo</label>
    <input type="text" class="form-control <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="city" name="city"
        placeholder="Ciudad" value="<?php echo e(old('city', $modulo->city)); ?>">
    <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback" role="alert">
        <strong><?php echo e($message); ?></strong>
    </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
    <label for="state">Entidad federativa del modulo</label>
    <input type="text" class="form-control <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="state" name="state"
        placeholder="Entidad federativa" value="<?php echo e(old('state', $modulo->state)); ?>">
    <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback" role="alert">
        <strong><?php echo e($message); ?></strong>
    </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
    <label for="date_module">Fecha de vacunación</label>
    <input type="date" class="form-control <?php $__errorArgs = ['date_module'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="date_module" name="date_module"
        placeholder="Fecha de vacunación" value="<?php echo e(old('date_module', $modulo->date_module)); ?>" min="2022-01-01" max="2022-12-31">
    <?php $__errorArgs = ['date_module'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback" role="alert">
        <strong><?php echo e($message); ?></strong>
    </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
    <label for="brand">Marca de la vacuna</label>
    <select class="form-control" type="text" id="brand" name="brand" value="<?php echo e(old('brand', $modulo->brand)); ?>">
        <option value="">Seleccionar marca de la vacuna</option>
        <option <?php echo e(old('brand', $modulo->brand)=="Astrazeneca" ? 'selected' :''); ?> value="Astrazeneca">Astrazeneca</option>
        <option <?php echo e(old('brand', $modulo->brand)=="Sinovac" ? 'selected' :''); ?> value="Sinovac">Sinovac</option>
        <option <?php echo e(old('brand', $modulo->brand)=="Pfizer" ? 'selected' :''); ?> value="Pfizer">Pfizer</option>
        <option <?php echo e(old('brand', $modulo->brand)=="Moderna" ? 'selected' :''); ?> value="Moderna">Moderna</option>
    </select>
</div>
<?php /**PATH C:\laragon\www\vacunas\resources\views/admin/modules/form.blade.php ENDPATH**/ ?>