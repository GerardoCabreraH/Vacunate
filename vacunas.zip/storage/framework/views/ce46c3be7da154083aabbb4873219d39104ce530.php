<?php $__env->startSection('title', 'Vacunate | Información de la cita'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.header-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main id="dashboard" class="content">
    <section id="formulario" class="section-light">
        <div class="container">
            <div class="row">
                <div class="col-12 col-sm-12">
                    <h1 class="text-center">Información de la cita <?php echo e($cita->code); ?></h1>
                </div>
                <div class="col-12 col-sm-12 mt-5">
                    <div class="card shadow">
                        <div class="card-body">
                            <div class="form-group">
                                <p><strong>Código de la cita:</strong> <?php echo e($cita->code); ?></p>
                            </div>
                            <div class="form-group">
                                <p><strong>Nombre del paciente:</strong> <?php echo e($cita->name); ?></p>
                            </div>
                            <div class="form-group">
                                <p><strong>Email del paciente:</strong> <?php echo e($cita->email); ?></p>
                            </div>
                            <div class="form-group">
                                <p><strong>Folio MiVacuna del paciente:</strong> <?php echo e($cita->folio); ?></p>
                            </div>
                            <div class="form-group">
                                <p><strong>Ubicación del paciente:</strong> <?php echo e($cita->city); ?>, <?php echo e($cita->state); ?></p>
                            </div>
                            <div class="form-group">
                                <p><strong>Observaciones del paciente:</strong><br> <?php echo e($cita->observations); ?></p>
                            </div>
                            <div class="form-group">
                                <p><strong>Acciones:</strong></p>
                                <a class="btn btn-primary btn-block" href="<?php echo e(URL::previous()); ?>">Regresar</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vacunas\resources\views/admin/appointments/show.blade.php ENDPATH**/ ?>